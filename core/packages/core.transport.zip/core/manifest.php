<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'f72398d2112200881bf93e8b265d55e5',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/0e17d620aac58273e2110219cd6943d1.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => '411e128198cf204770b943fdff46fa2b',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/e6e4d5b56071c6952c7ae044141b1c57.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => 'ecf272e9665924b2ad6801cf63bdc97e',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/c29a4c0699ddd7d7f37131a67f66efbb.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '7068192259d21383709ed6d25042d93c',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/bc437287df436bb85b32e0e589b99eed.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '0e03b92c790643f987b8422ef0e4e204',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/410d92abfcb17dfe639a7925a6ecdfd7.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '45a496929a2af79940cba73f937d31d3',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/52e7dcd95cd45a89b2ae8230aec88bf5.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '464897b662842ca86fcaa566969fe47f',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/3d4c7430435372c5b0141e7efcc6bf55.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'c751817c0bf7120350942feccbb34571',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/26ce3978a4d78b3fec690cdbaeb22f5f.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '92505a3a0443c1fd7e0308b3afeda062',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/435aed3e6c37fb2deaaeeb9556234c16.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'ff61d52d64bd0d03850d2b74488ed5b0',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/02e5c43843b0eed1df3981a646661bbd.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'e707e49f23308609adb56e86e31cb8fe',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/061f7a4dc1eea2e5ba4177fcb83b5db6.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'd1d8e6f55b3457f91ce095f526d361a0',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/16836e5f9c71ccf7d96a503e466c098f.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '9a78d0326ac164ab692c231801d0534f',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/25ae0efcbb598f5663a521e5ef7ad4e4.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '02053e2bde7eb21c81ceb0f5d2743e0d',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/be4467620ae4cb63b5ec96c1585521b0.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5a2f9a3f628a8a1caacd8e5b30ff7cbc',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/a074e6523feda759733736f8af49699c.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '26dead7910bf9828e024332be1a362c6',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/a7567cf0c407b5d26fdc6c979207d22a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '54cb4eb007d333e9d959ff06660c958a',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/6fe8272bf7c5bec4e3c93f0918d5e44d.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '424d5d45fefb6046f9178e6968b2a56d',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/ce5b484ce25455e006a170bc7583b915.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7012b4cea8f729aec580bcaa6fc78701',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/15364b50dc4fc575cea7e0ea5bffa492.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b47d24f6892d444e6bdc2768e6938938',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/8dabb802cf28827fef6656b06e4fdbf8.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c9f268077d9b5bceddac5cfd6aa27dab',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e6e5d0f7fc98a68159c367fba4cfd2c7.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '11970b39937b587a41c25b83131933af',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7e9e12d863ab62318b34f84e2cea9736.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '37a40b519e6e1cad3ac36f97f78772d8',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/90b46524a53ba01920e72d63d9308cc7.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8344bdc092a25c01826c4727d84c46e5',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0dd821177a0973488092020948481e94.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '06625cf7273f24169786eb8cc468f19a',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/7f8361714519c7c1fdc9d07578f552b4.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'efdb246d6f668757f397ae7a698e6751',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5f78cf672a00bf8699a6e74de5e0faf8.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1154c669ef63483b4eb2ee34f7f2384f',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/a6218b9aadb26f1d2bc42159ca61c303.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'daa4e0136752f842e455b2eb26c4b78c',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/90b25cfc330a68ee0ea19c512592cf9c.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3a19da78b79182331f16afd7d65e289f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/2bc5145da6ee247f74efc0afe03c8ed3.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8f3dc98e3dcbe236ab6830c299b96991',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/5233e380ba528b9e7f320f6494f0bfff.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8ed809142e72df2247453a9facc61b47',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/287cfdc11a430351a501aee698ecaeed.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9ccf84dafa6088a554b20aaf0f3f81ac',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/21e478e8b091315d04b144676443f781.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '77c3816a4b14a7bbb417bbf87f113add',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/01cb084225af375964b164ad01deac3f.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '697c1450902fbfbaf4b815be3e66390a',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/33844bb72458c0cb42d1ca5c6468e3f6.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '04b9e72e29963aa7586587d5b53b2024',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/caf7cb5686f6ea218ebbd801b3fdcf22.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e323d75aa6fe232ad49727bab8afd1b9',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/bddafcbc5c8c50853f97e036ca931488.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a4fa40912a6ec3ec1815840c87da0151',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/ade5c12e7b6bd8c8df8768083e8999fd.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c34fbd8941bfe967b59eee4e58941cab',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/8b90faee818d9d1222f82f1a84d2ce98.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '558d978eb6c50a37193c4a9e2759e42c',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/ebf9d48875559874ddc5bfdbb3faefec.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '74da692c9d7c054c8d4a55f32613d72b',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/889b3cefc8b106c8ebae0df3abdc7edd.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f3e85bc34e950c8ffff8c62e2e7e2a0b',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/478ea33eb4862ff21ce4c421aeda784f.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6650987e345c7fd4312a4d01ec7fedce',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c79dfa660ebff950fc4c35aed289049c.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ab464b8455dd8dca1c9ef47e68b4a69',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/eb1c6faecba209b2d89d716018eec64c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6d768710b1bc2d4d9b58744997dc63d4',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/76ebfd96d34e9ed5aa7d5b1f0dd0f6e8.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '75a842235fc9b7de13d7386bcfaa2b35',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/4eb6dd0465f96399f8a06886cea9a55b.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ee21ac91eea0f846880c85007af9108',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/577a0a139ae995bc91e928eae3e98aaa.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4c341c0681ff64ec29abb0c3c2c73619',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/0ac60424c7eb11dcd1e5e60c30e66f27.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e38bc7cfb6f1b7ebeaa337bc8cd6e019',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/670cbfe922f037143ce2184ffca2a58b.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '11cf4c894ecd0f21ffbe67b87c7d57ff',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/ff88b1ce79cc253f7baaee29dff2828b.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e13c002a1df20cd4bd161564e96f7ba9',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/54f2ce66f910bd790f18003b3e565e9d.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '203670a39a281e6f47ea23daac2d32db',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/63dedc58a4d4970578305e01a9836417.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b9c0aeb4419bb443c6b8cbe05722c0a2',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/0069d032185828bf4215a1dafa8095aa.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c24f6d7bc1fc82a2cd43f3ab3d8c277d',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/fce56f45cdccf04b91fce28272290c3e.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '52607e8f68f8d7109a15c873869df3bf',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/0266199acb52f5ffd58cd830dccbe7f7.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2eb85931b0dfce6f487746e29961e368',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/cef3624abf7522cc0d6a198e7067162b.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ace7822a9fe946b6358ef1a5d19bead8',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/09c3c78f5a1ec684a709f169ed871902.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '89732a5f6a684cd45687737377c66b15',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/10b6c480d3893be2e13fe1020ee7764a.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c9f2b558d837433e0c5429c923e11c70',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0824dc77349b4d5b7f0ed244dfe944d6.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3473656a0bb8d15545397c3c55dc7c3b',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/c4f43dcb1cdb8f4afd4b7f926dd767e7.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f1038667fb6277f6110483ca8917c69f',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/5764f08ad2297aba7327b3160dde1ea1.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4cc002cb3dd49e53a3a70abaad76dac1',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/8486dd230ba9e2ebef4b2011366f9447.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f1c06727dd57b09044e678bbe7351005',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/87e03fa89c38c84222481f802b963e4f.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5c4819fe69cce189d900940362631143',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/e4268b6630a24840ad8db5eecc883951.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3455727a763be6a0ac20283c5508d93f',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/dfb3412218d41640f9948e836f26c9b3.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6b3628d7f9b7163986c3bb5da8021bc1',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/b6626c15ae790926fc50aede90e49c3f.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6f3ce144e94e87a5993e34fee23f7504',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e7e5fbc2d4464e9da97c4f3cf708d138.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '71623c3c9c0c172f09b1e36cd381e6b8',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/867a65a2c028a7b790aa2720e1268bf7.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0365908174b85fbe788374096fe1aff9',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/360e34e898c5b9965d2f0004485e43d4.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7196281ff1bb344207de676775dd0966',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/dc8c1fc0bd2c19555921d2b544fc61dc.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4529068e2d43de0bf9d2ef4f6008c0a2',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/f8c78e0f6ec785819f5cd27992acf3f5.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '803b05215852a37e11527b4597e27ef2',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/b6d9b8740a02810a801289ff1ef0f2a2.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2fc531e0322da9ae3ead18cf8c8730e1',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/baf901adba70cc59dccfb0fbe9b0a044.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1e982f07b0d8e98a524fe9fedee839ea',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/dff0da076d29d6d852e6ee506b30bc06.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aff8edc02536ca05bfedd53dd752edb1',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/987c68dc42d0c20ab8c185a6bbf83e06.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f925aaacb8dbbe9c46fc74fb2cfb6613',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/e67c25691081e6d480d4cd134c44f931.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bf0174966f1d8c371c18ed04a9da294d',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/33a04f6d1254ed804fbab8640c592dc5.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0633d6fb34144fa30a18d3e7c21e2b8e',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/1e9d9f211c521d3709d47fc343ea6ad8.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2208b38b55467f119e0c00073c6ad768',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/11ebf1d25e744de8414fef9860712363.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1c5a23b6b1f82ca15a03ee7a668f3ee9',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/29c76331fd5101c54bc78790c8642970.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9d3d9f1640d06890b4489a2fbb2370b8',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/ee57b02f317da96efa3e3a42e8e96ff0.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '23b8ee980cfc6c02f8d387f2d1804d98',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/dded551477518726e8236d3aaf9933ca.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9c9f34ef7ed80f9ddf73407bea8b4c88',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/6ac59fe066ad72efd0e9d4b1814ce3ec.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '77772892dd174b0bb6816877405960b4',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/6752afb92e47c6b0f2a4c6895388cabf.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6716000214fc9891e14e6ececd69896a',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/13b265eb00d70fd28f4d1e0529171641.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6be8439525e8c8c91f75f86cafb57208',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/f844b377535937b8c7479de6c1b48f33.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '427e7a141d25d2bbfc117c1bdb81f7dd',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/6330ad52031278368ea25e860cda9e97.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd475a6ad0ea2f8248a27829f23126144',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/feeeae2288defaead4d96e327f4a8eb5.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '74d2ba44619af72b98c9012b8c25d8d3',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/85cc574c6a5c6e3ed1637383c5d23603.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3bad4d316091367e58d9d30bd7adaba4',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/d37f7da85f2c487349fdb9c5b1ae811e.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12f12e7e61254f45275786b0ac314518',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/0fee0876dd92a04c762ff55d772df7a2.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '714ec4096c390414ec187ac01d3b715b',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/9826f6cb99fad5b369034c329af9b500.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8900eda5a86784e3b97bde4fc6ca7d0e',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/a6bac20e0f7327b15f60664713f1049b.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3f5d2261020ee1e681714244d649bc18',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/854ebcee2508e85fe9922e210937a8a5.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '387efacde344bc42d4738cb1cf4063dc',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/03a469db56bbc5e62e16f6165408119e.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b5284a70b3d7e4a8ccb964452afb98bd',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/0da846fb70749ad7e5fa8a74f5882093.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '42fa5b424517c36c720badab61cf03be',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/3628b9536aea189e37367d3a0e88fcf1.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6cc16509b4e094b0202d6dfcb85a9bef',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/dd8eb72caf94200d066ae0aa4bd3c980.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '73bc0c6385921245bb8fd238cfaa0903',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/450e802fb2ab30a27bc16a99203233fd.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f294e4e46d82b76e34cf26048a3f1737',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/ff1fc31b01397e83108e4d5f34d07c5f.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e5fa6513e29ecb1974d5b232a3dd7cd8',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/0d87702e32ec19409837c53f11ddc0fb.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '71ceed2edaddd62f53476da53863afc6',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/389bcd60dc7a95779e2584c65c024866.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '13a1ba2f2e698bdeb4ba2f6032e639f6',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/5ce64734eed61b5e8a0946f2b39d3636.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b139b64e8418c61a46d991efb958007',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/cc7622cd1d5009a123efe403a05019d3.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fa4ba69209cf009c68eec7ce3ec59c6d',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/46f21a3f369614e75525a54ff1fed1aa.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '63a746512585e085158757b136394b20',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/064bda9ff0ff0139cdb8ff853407f435.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4bdcb2c0c15fbb4c5d265755dbb6afe5',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/74ee788aabe0db66e66093e9573fbc3d.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bfae32819c5472b5438f2089bfaf6605',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/4559033d8bbf63c30a993915c5ff7904.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eda590ae031a1d2bd2e587f3a7321178',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/3bd89638d58b8a85c968ffbd6ce1ba42.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'afa80bc0d6fd1b9359dad55748476f88',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/e28434b007ce1830179033fd1a034274.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '93174a4a162049c194528fd726627d73',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/090a11b4f3ed1db24705ea2fd4d19fff.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '73f5d42fc72e66bbac9881fb3072c1c4',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/3391f0a2537300cba5db14ad68739264.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '76218a65060286b5e6c3232cd2a4e39e',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/3d353fa8369ccedf4488a94f9e7288c9.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '56b753912d79fd205a1beb5e4301b64a',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/7bc6172f72cf25cd9a94d0344ef401a2.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0f640100a8b554f5186fd20be6131458',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/fcd6b79da0c481872e007319bea58ae8.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '44d7b2f39209e804fe4a70aa3c1093a2',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/e36b4c243c8498eb64aaea9c0064115b.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '627c38fc5f04112e9237c35306a936fc',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/f48041c465b9375520cb7b5fa961b5bc.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8817d50475a96bee5546efac5c583eb4',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/0fb013189fbf771670abb6d8cfbd5e42.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3126a5337619baa51d1dc160421a5d0b',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/33a040f8a5d497a23c1ac53f2a17c5df.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dfe0b26b4ab024559282dad18a55e436',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/b54c20b5143693799afe974024b488f9.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd6e0e1dcdf75956ab2c25a1df03ee5d2',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/20ef84589f02b41f6d577fbdf6aaf737.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4a76f277cb3080a14fe69b185a9ae960',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/3fcb4492d292e7d9660ec36c0b8cf003.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a72f549cf45afbe6e7ff19e6b35ac5de',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/1e65c782d9aa6b34acd5dda5f51cb0fc.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a68400b4db883deaeef0d0d48b08c766',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/cdac57576b4fad414966bdea269eb9a2.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a11cac09199e2d88f94139b3bcfe5e32',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/e34e59f48907560ac473e89d3bf24379.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '525e456f93c0534bd4ac79be5cab4b82',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/4fa58cc1ce6bd13465065fe6f5ef32c9.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e366ff3677aeef5d20a5342f6929697c',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/01aea856603c901380e5141258dc8bd8.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f4354060130d840154553f4cf2cbab7',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/fef0f8b2ac898b465cd5906b6756539e.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5965b38641eeff97d02473edd18a5fdb',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/71f86d856d7ef15575f4b43dc2eaa5b0.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c65e3400064f20cdd605af14abcd4134',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/0fa0ca89b80da696cb62cdc517992cbb.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1328de63324664389eec7ad92e29f163',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/31be60d9404d3316a18947463209bba3.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5584aec5839102bf30eb89ce26da533d',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/484ade24c078bdd405416ded3409dd7d.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a0cdf7444b1f9b380baf886abb219491',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/4026041aaf8a3c2c659f3062ae01f25a.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'edb23d87f033751a705460023354e043',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/bb908420e4248d986170c3e118f7d894.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6e8a9c1fd189f9fc51359adb17829f27',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/ad1a041ea5f4c5e43e836ecf85160b19.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8105bde92899b93612eb3c6dbb05e42b',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/0aa6e95299624dcc66010f82f49ecd35.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '26f850dcce0515015fac25570767f22f',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/aa45665354c44d1d32d159e0fda59a39.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9db635f0ebf747e43519a86352ca57b1',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/4d81ae3b4df8195f273c8518ce066cde.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '29a4f0c80d2cbb048a7ddb1aec12643c',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/a85563aecc6b602dca017652854d9d5f.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1c2c67eabfa51a8e156b9ca3b370122f',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/afe8938233377a4801bb0256f9d3b19a.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0246078e5c354350844772ff54a91f86',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/61ef4d744a5d02d90a2e60ff9d8737eb.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6fd55a3a17b86fb53e9f52ea3e85a2b1',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/ee6217bb57c5ce769394efce40040684.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '33933e963a5db028a5fbc73cf6fa324c',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/58474b3bd3a40ed5c88af7097313d73c.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '275652966dacb0ac2b2ab15a1da30b9a',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/c24ed3e1ecf0139b69852e86b6e20410.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e2c54f0a950378495a8d5d9905210e1e',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/ddc7abdf20d24e3f38b7addefc54b3d7.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3bb1e694e37dff548bf950b587a9bbde',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/93da0e344d891e30f41badbe893495f7.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9b44c94b01256c13ac68485d19cea17c',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/3e97cf7adb8967bc9bf718e32293e13b.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '612e513419c928249457bf9ef3498ab0',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/42ae774661def340805ff120242a6764.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1ecfc2ab14c960483bc031061cd7e4c5',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/92e9390c8b794d6910d1275949a2aaa3.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1eaffda077bc9a28077e01ee4f5777bf',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/dc866b3f5668ab36ba80a5a69acb1a63.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09992c1d2eb10c75db796423e0344cad',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/bf02ad4dc0da2828fb278cbd591baad2.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c7f734f3e0179cd12448d2e5d9f5a7d9',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/c81ae56f94a771eeeeea8e0542731529.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '065bc23128d177013a5638bf5ea035ec',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/75a651635b9678310cd71dc673e2c778.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cd247e4517d84c18bf34f726fef7a874',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/3b3aceed22c8fb129abd7549bf55b196.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '52260af56feb1cfcbfa815853a99a258',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/6a2d2008d6f58ed74b37d6a4d5192840.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b9fc4ffd46539f1edd4808120b196d59',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/60d4e355c64259121382be13a3d58f30.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '74b4c0aab273cfb810d67779eef38df6',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/bbc7f0f5365d13c38fbe739b40c3da00.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '07f29597ded062eb4aabf0f03e4e64ef',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/d6eb67f4e91af3c7199778048fb0aaa3.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '187a9a5c35d73afb06b6ebb4d1d9fccd',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/e9dbf9660d266fa06d071c8423385f5b.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '82a8aec8ae93e9530d807ec14495a04b',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/f4599218cf9150b991a62f7fa3b3b27e.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0e2ec180f60bbee5141d43091b00df33',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/3f16c8d5496e1126fd17092ee7b87290.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '904e7f2e6513a7c8b8c43f647151a317',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/a197d2fd5fa47bc911f0cc2424e27fe9.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9c09755b6b555cee3a8caccf60be2756',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/9a44fb017df2295b9dc13d26f4d0e9fb.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '40f10049bb58ca2e4c3cea37c654427e',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/9c53f03f532e0d6417c23bd34cdb3bcd.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '55ea8f5eb299ae09d2d7ae1cb8c466a0',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/305621bffc814f1a51d50398d8351ca1.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '985337fa5217cf3f5f5cde29c7226796',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/015e1d1cd6914487940ee039968e7e27.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dde1628991c4028986de54223a901c7a',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/a56aeb2e8cb15f07b7ca9b4fcdfc12bc.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '88a929090c2528982dbe7fd47693abba',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/ddafab5a526c302abdec4565eae38606.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '821a052be10b0b16d73761587aeb3c57',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/b45b9dbfce6833bdba321a2e5656184d.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bd6e3ad3fd1059e7e013c7629f6d5d4b',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6b7785442edc7f334fdd0dba2a6decec.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9010920df9f3bfaf97e9d72fd2a2188c',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/81b6512354b8ddd7323bf597639c3b6f.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '417e01cacb2ecb900d1550d86430c5e4',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/4ca0736d493839312449baa64e34e90b.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8897fae1abc1603107aa064e20858c25',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/5ae1756898762ac1e0f736257128054a.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f13cf6b804c592b487cd08eb496370d4',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/bd335908f108b81703df6570feccfc4e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '04f9b694f369079cb62fc27a9ae6a7a4',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/f823c29600903adb91a440f8e423983d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd504641f19db1ddceb39b7caaa0e8405',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/900d01eda15bf49b4b56e5e7315e2553.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2c6a1bc651a4197ebe99d6caebaebd45',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/9d6d42cab7ee58df5392161808faf4ee.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6ca841f9ff7fb177ed6b1c195b5a6596',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/16b59c36d2edc6c9d12865274d05485d.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ae8b5122a6531ed8f7c3842227ebbdd5',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/3d8e0d7b83177002c9b9868fefa3022f.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7643d80d946cebc158fc653113252d54',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/af9b2ceec6ec0d90abcb67f47506b72c.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '25b513195f7b97b265efd35161e24a3f',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/3717397bd4ad3dac99c2a3e157eca7a7.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '96fa25b82d33a1d7d29fd2053f3a4550',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/bab4098264d9f3577ac1e4da1e49165e.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5e5c3d926f7b9f4442c3d6f537f9b992',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/a04ff8d8c56c024248ed33b66ad539a5.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8c60d1bcbccf87b164660ea0024cbf8e',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/a40d270f16cca0f90a3e398cc0cddfdd.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '30d15a9d5bcd6ba246ed852ceffc50c6',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/5e9d37762285c3d81c372759682dd953.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eff384aa0c828df7a03a696f466fbccb',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/da2d3d05bf516d0511273993f1911deb.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ac58770a346be146ab7e14d9b0fa5071',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/bf785ee7825438d7369c5fd3b48ccf52.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f9e07fae825972d8a8f5d7530a7c7e72',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/c1a87a314a2a75b0ade5180a0922a1fd.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6e13e4917ff5ce343cb14855caca06b4',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/52075997e2b64c945f82a4266b16d63f.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '990080819cd10f952d044ffe1f9ae48c',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/18e6e2f62128f941860e387faf2a86e4.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b92003098a352f0724879a96fb788eef',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/4c4375b9828ce2df5a474242b65bf8fd.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '67cfcd5d769b3205a9410020d2e26787',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/838c2033a339f3dfee8e74148179a766.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '91fdf40a1a1bce630ab630a27927b0ae',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7a78094a8f036d3f221c403422780e45.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2164db21f69208d2bab05cb6ab6a34ad',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/a7238e84e6cb1732cb5981f9c19d2417.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ae979f860ca82c483b70a67a509c0cda',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/21f81885b9005c299f08f666603589ec.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '33a5165b8085776dfef8ee5067737459',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/50af00ef012b6afa439347a1385d413b.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '11e4e40d19cdc5d18cf298797f473782',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/2ae4e50bfd87d66412455a08e3a294dc.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '53c9a93c5edc8074f93f26627b41da22',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/ad86d475be2e52725314baf555057998.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bf87133c1fab2cd3c2563f5f3836175e',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/df1f97d9853785a8f16ae8a1b4904ee7.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fd32dc310c8c420f594e8852dc5e9233',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/908143bd56a5806260fcac1dd50d4acd.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '764c7b7f5a94cdd8c8978251da1626a5',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/d632cab371174b179d74964c3daa8373.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eed8e7b261543f41f0b1626a16af9003',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/985241fe4fef2ef54eb3b35a3c09baa0.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6607edc709572bb9eaf3527db2d421c0',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/0fe20398bf968e4454d95cc869e06584.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1692f70bcb00536c555e57791be60b30',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/f40ea52016685b590b74aba3c5758799.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0e69c3065f78cad2e3a06802b15e6183',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/09306f7286b766379d240278aaee8b44.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8b71679966daba466326cfb93f73cccb',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/e8298297642e6765678ba1cdd28a2f7a.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8417e1e88e4f0ded35fe411161848dd0',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/f4d3ad4ebe06de766408707caa8c557d.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ef033945d6e6eff50efab579f5cb5cc9',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/aa5feba2baf4ea26e5d54ff445c1fac8.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6dcda2792a39a9b5aa9b7b35aa7ae6a9',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/e67a41b8619f2ff6b33a1fd7a9c67396.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9842fd078d8b9f69264d612431e6f5dd',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/aa7e75af2c84efa08e0cadeb092baa37.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '992959d6a4dc02368f348e16d8a3d61d',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/44c89bb073a6cbd6ebf131a0bbbf9d06.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e89e06a5fb5ecb9b4c0b3b4d910c8f26',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/98a26054971240f1cd95f07a9a53c820.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5faee3e3608d6a0c5eb7202487434ba5',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/acf43643ed34ddac622d9b07b579a9e8.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '970dac10fff35b257944eab2f1112c4f',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/71502136cfd77545078de34b691ca11b.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3f2e970f0d86e42a6949d59d3fcdccfc',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/519c278feb856adf7550096972e892a3.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ce33dd54df9e5793be8eedc92aa40c02',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/1683fcf98142cc62618ca27be862cbc2.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '004141213f714f5dd9caa1373158dd5d',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/53191a275e49ac6a17269aafd8e585dc.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '23dd6d7e6761f4a56a5b0ff7bb8328eb',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/a3842c52035443ef4ff12787e6e08fc7.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '285a2280165acda42b73e9e30ec529e0',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/f7649bd0c399c99b1a557a3c4df49f70.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a23131a8321edd7dadf4720f77c897fd',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/082b69c265988bd900e24105a038b193.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cfa56dd09b79a9983a5cf668c00fd5fd',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/f64de5f08224ee60ae30ba0f6d73d098.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c15a4f2a3b450246e6dcc82493f6d998',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/0fab525c88418786551e06eae5a97878.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '771a471074168429b1845dd9cb00d6e2',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/d0a44e593268712e3c402747b82f9bb4.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e8c62619cb694900f552b5740ec8f45',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/9ec3285e08cba8f8a853a794c696ffc7.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f3bb633f13eb5ba38ce68a33d8d8746',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/0d30ebc0f3b17daf125e4740d2ffe1a9.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1da48c17d89613e9e49642825499ad78',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/515f82e00b1a3661d17722140afc32dd.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4b629cebf6b07bf63cf11cb39c12ce5b',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/75a542c3469aa33d37fcac7af468d46c.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '064bdac01ff158b1615b980893ab1958',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/1da49c03a0328411f6ab66adf7593fce.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '282577cb677e552cd65a92edcfcc8900',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/5af11b385d69e7884f1b114ac9add3ff.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f6a924b381fd21705e736fe31527af68',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/e162d64ed104194ffd17b459b64b16b4.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fbd309d4779f5219a676dd6b63b1c872',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/8de4d609f8e8ee67735f002d52011381.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a626c63d61a714dad05d303e7f00c4f',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/df452dec1d5f71660c9ee98d8f18b22d.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '92df0b66cf56aadf9415c73b6406a229',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/93fb65efde5e5b7362891f32c7d30b4e.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '92c81a48ed82f9692f162120cb9d5bdb',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/21fa03e2065448d83a8e176fcf102dca.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6471f10e17b1a3d7a0eecad4680d7514',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/7c13a7d778ca56cbc0f956e131af279b.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4ec399eb8e7e1ea76c9fc0ec4ad73d8',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/d72d400bd8ff380f84f2fc7db6cb7719.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b7795d3988450ca44bcf366a7bdbc257',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/9b6323c62558631e2e4a4da3ef1bde36.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed9de11c4a5a32ea7176ce0acebcd32d',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/f879359b035a0aa83ace8ce4b5141d20.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '423a8d873d4970891652dce3a36006a0',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/7ad3d127a2dd3527fc6a54886213ac3d.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '336e40a4ff8e47259b6c1a84d227f071',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/4becdc0c50fbb02ab40d78ea91cc88f5.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '63f8fc12aa323e0d017223ed9d63b338',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/9292931d2810fdcc8d847fb05a78cbdc.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9962af98c0df9638086de63bbb37ea12',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/6bd362942e45a36f46f9b04dce3ac107.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'daf6f6ab315564c42c946ecb1449e0fa',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/54dc2bc7007ec55ceb8bf79dd246197a.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '385d8a234e3c4c615b288ae05b9c0295',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/b51dd53335e012f6ca271c3ef6db8db1.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '477b4b6eb0b8e05539290669101b2862',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/9b32a72744b5b75c98e384debcb1868d.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c88645e56ec36e74eec885fea8dd1639',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/9e36e77afdcfbfe70e7b2802ee1846b1.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fcf3be1d0e6734d5cb1bd6f844491413',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/b4ca09207fca5b8e46dac2c4fd0fbd1a.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42c4331409a367f44e46e9300e9bae42',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/fcd9c35175c238db5eeef380af97304f.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a827ccc1c7f5c91e68af481f7ad2d06',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/85d9e793a7c0a955b56351928c6ef6e9.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2c7b273f013e8ef4bda90e566b9a7e24',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/ec31f93f147a97f5c63a4c7999a232a1.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1c9c82583d9c031010369e64e909a556',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/8f1983c9b2be9c6540f72430e8c8a228.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75297c41754e7bf533afe99bf52f6d8a',
      'native_key' => 'photo_profile_source',
      'filename' => 'MODX/Revolution/modSystemSetting/35aac26fad61c52371d980ad23374cd1.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '77d2f4fe6673fbd24da51e7611ffb98d',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/34344a5c0c045b462285258c8b5badcb.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '87809fc007fae15e45fda0e2467b777b',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/d5f9f0e49960a747658b955286fcb28a.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '59944ae3ace334a230aa4c1d79a225eb',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/5c1439830980a6d02fd49c9a14148c77.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '035673c01e9bae4376e5a9b4f6bebe34',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/7df5fa7b0743dc7ebb8d523f4f575f5b.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '34a5a984ac3b8536431af20c97e76279',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/002c1671367301572da610a1bc0b2ecb.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bafd52860efa03d92a3a436e3b963f91',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/93cd80d8f2ae543156e510db1c38c234.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc4d8c45d567299c06de444759cd9074',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/86f3f6d5c937997a31eb2dba4b74adb3.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c86e99bb4ff9d11a3fef7fc449e28636',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/52e5c272fd166b54e9c6e295bf37e7b8.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e2a4eb0052cc2eab413b8bbbeca4c4a0',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/c9e0824f19990b3c7339c459011c9ab6.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '24a6d469ec52afb6f1c1caa37077ad61',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/1e9d5d2dab2f6be56ae6d09825d4ef35.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21ff73e349120ed94c5d95686d22108e',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/d665f199870aed321cfb1e35fc758cf2.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d4b2372b1a32f8b15fece7e25f01a31',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/8e95fafffe55a549abd7c0f73b613a43.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c3a18708c84ba3ae62bafb3f122e517',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/446f6ff0a122213110cfb285f34efba4.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '348f969f5c6e970854c55269469da3fc',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/7d59a8dd9b07e8a1389d68a0342ea148.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0439c8c2a17c08463834b39dbfca2247',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/971eafb808c5736d7ba7e03bb1f04ee7.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '696e711959589b34952903f5008cefb5',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/315fa04edab19db147707a51ac9d4734.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cf3decf1f249fb1035e51b324d0a9580',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/6add26cf79432b317ee7c438b24d2ae8.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4b28fcef27f7e89ad4b29f123ae2cba0',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/627aede3eb2140b7d7c8b5c8d09bf6cc.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5bd671b1ab37cf6736061465085a0035',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/0aaeab14778d2543e8fbc19a748a97d5.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1a8d5606dd2df1be9e493780b4f18f33',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/6015241bc70b76ec810ca1e17f910c0c.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f33c90fbef9324f3a46944169fd5be2',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/f901e71392b44265282cd0a47dd614c0.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '10caff6ab84e6f15539682d4fc9474f4',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/89706603ec8f5adef0e623192b8f437a.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3bfba0420dbac7ed2332eb481a62a619',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/ae53402a5bec674e87466e0ffc317fd4.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31361b3e3af561ef4cfb5012bdda22ce',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/bbaf4f83bc571b755092ce5066182f99.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eb3673de8161b189f5f80576fd8cbd68',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/83cd9be39646325c5773c928914ab73f.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bcf42bbf3614627942a2adcc822e9d95',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/d9ca8aa015db8bae10ea3d067cc3c26a.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '68022cdd386ed612cb2a73a905b211d9',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/fe9cf97b54edded82f5d32e22451b9d3.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1c918e7393cff92f3d594175ede628e2',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/6718cf3f22a03d8d87e1bcd429834414.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '11765b799190d2dec6f138e28bd31dd9',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/09597432ff94ff3d4666e97420e4e1ba.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8a3d837d279c9e28b4982237082cb372',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/d0213163c97d79a34f91e486b52abfc0.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'af2fd8c14a25580afd8308115466fdf8',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/8726878fb85a24f188f0e84aab2b30da.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e6eb757b63e151ffdab6e36456255a4',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/8109f5ad7eb5b26c998c2218f9f5d358.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '803870004b0fe0ad62486d9884ccfa19',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/90407a53182e3eacb7a67abdb3f18b02.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7ec47dcbe369f30f10e2878862bc2788',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/a5cadde315f08fca8dce155c9e906701.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4798849e5ab4414a6edb4fd3e654d73e',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/2c98c93aa3d6d7928f5608c23de3bdac.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed9950186a71cb56bbe8059747cd2d1e',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/751bfc113ef93f33ffe14e140f92a9ff.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a1f1370f19d58b7dda0a9a226a13a52f',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/86fd89962921dbc277833ff4bebc15e4.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3be4c6ed2eeeef6cf7bb3c2dfc79cfd',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/31026c8b2ba277f7955716706e99a85a.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '782c5e0db9e5a570319b4956565f3c8e',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/7bf1d5abda6e9515974ea21738965eba.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4243d706194d2e0913f3f33465423ccd',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/923a49a8f7261ec0a9474209756cf008.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be56eda8cb5cd21fa6b73ebce596032f',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/2ec2054047d1aec28ff28ad68a4c6fb0.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '815294e5b3637f94c92f32fb133e9f82',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/608b3c6624f945af3b196407f06958fa.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8ecc191eaadae99586afa15d8d2111ff',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/38579550c1554badc0b88be1b23d42af.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3235bc365a692fa30557355ae82ed6e5',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/485948aa917bdaeb2a7838a467c4fc80.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fa0a7f43a1251b923159e373fffb6086',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/20abc4bd39430be8061e8ee707bac0d0.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0901f3b38a93317726b6212e42a1e925',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/e18446ee76bea982fff0da965cbe0df5.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '096f96fff5f1f6da9ec3e43141190ea7',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/875d7f5632f0224ad5e62809dcbca943.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd7fcce4384eccd448a20e49e2c3cecb7',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/72c2e13efdfc6b7a38569ec2da10935a.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0db8335ceca90c3eaf5ae739a3dd3c29',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/fc712192e65e8f88920a7c69fdce827b.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed2e45cc6e99f707f90865d86a7079e0',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/27f963fa02474fb6d160e98ee4a0ba4a.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd2e4632a77e2d0c207aa1aa018502678',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/7f4e348e969e18f1b0073a27b9ee976f.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '49bbf89297a6dcb4387896bed2e1e5d5',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/f3d70d4ce2c649775eaf6c67bde6284b.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6a9fbf50c3e0c9b2d0d81908e09370f',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/76b8606c3609de2cd45bb9e95fedec8f.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7680de9ef9c3ce15f76c8f706eb66b52',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/085569e6c7700409803751983a300cbf.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a51c6f778d94cac59431e650b509e149',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/4aa94fd12badfcf4c11a12c1af622561.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c8a289255aeed6d62d982463d64025cf',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/a2de3e6860e872f868aca944a98174b3.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e1b79abbc245ba591b7e6710245905e0',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/9ff884a415471019c1ac54685c075fdb.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '13483f574f6bfb8116086697498679e2',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/a4e599df38740df60a05fbf8d50c84b3.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '131ad3eb7e71001b2cb121dd2e8491f7',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/4c35678f7ce378934eb371cf4fac6d4f.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '28b4e000004dd92fdd3522a2757d1507',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/40991aa6bad2826d2e5311fbd9085b38.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4879b968c7c499866b07ee02fb987cd3',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/ab43127f394e3ef96944accd5111ceb1.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2af521f39d3c8b712f6c2602655ec5af',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/553b0e999bd7d7c4dac3f5954d59a6c9.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c2104be8bfdaba342858cbb6f765ab27',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/134df7e9b22dcc9010328d52ae232a42.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '718d5edfad1ace97467c89e1e373bcc8',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/9ad421bc1b832ae767bbe4925e747181.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '35d2e115827390ad3e29ea6e923f0fac',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/caee1675bf44ea48aa53671dba53648f.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e971895da187c8c6bbf0824045e9be21',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/3044054660e124ff943981e0f5b6990c.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5eb9fac71bd3ba40b75a67440500116',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/117df3aeadf6c348a67a155f83833b76.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5ba256c5786367ee013bdfef67bea9f0',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/649d13c6757608b41c5f2cd22374b2b8.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dd2f4bdca3aba2adfe01b8b98396d314',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/64dc967a3c44671999c2ea6bbaabf8bb.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c996e8b0e71a1a0216a400c84a63a628',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/18fc66e46d997a81f5392f1377ddbd9a.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a993d12b9a7b1d6dc985124b09b5e550',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/5f35d649ebccfc4b9483dcdead4708f4.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31ade5f0891b094970cfff421d1aae6a',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/e609660f955e72ae472e21104d546cf9.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '16a95a0c9ef5506917db488737fe28cd',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/fdb8f7ffe063f322f81447c563cfb7aa.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8469239b49271f0d6fbae56c4acd8da7',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/ba9bd63d7674901ffca0f64a1806cf23.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fad83f71475e8ccc4aa3b871e9496945',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/a7867d19739e738a631bc31ce3a0e125.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b67db5485f296ec0401e4825bdb8a16',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/200fa4b329c1305111ff0bc38b6150ba.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '236b66e34b598b167a0f56f1f7bcc48e',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/8902bb9e5175eaa1084ddba49ac4c08f.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '219b2654dd665888dc6bc77bb92ae468',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/2aeb2a1c4a4e21e2d364f2b1d518d570.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21e6f1acb57adc7c9e4d683e7c540108',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/70c063314a7b98c659da06e067485d55.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8614e800270e681372a2cc6952e4a42e',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/b7b3f89e56cf57af5811c2a62e05ab37.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '34f6caded9d4b00b4ea69f55d69b70cb',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/c29a6350b0239d7c9a7b1a11a684d0eb.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fda0563024fcead27e1de27721006dfa',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/5b95327aa6b345e384b4e2d6f57e89c3.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd46c478d1604b364d9b7df5f7ea6e427',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/6017e6dab4f40ffea714d83c89f23175.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b0713aa59b0c096ef0e98409bad2d288',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/ee26e02dae0d491d86d407c6daec523a.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '18fab65278855711c4b326956bb248f6',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/374235034a516cd8948738b27af6d3ff.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1dc151ced1fdc113ebad94b0e3fa606b',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/43c4bda6c2b564e27abc3565f4f17af8.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '58c977fb98090678098a0d49ead1cf29',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/48c0d892dab6ae47be29d118e460ca81.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '224be6bf95c2321f87495821693c9766',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/5b1581d3aa9c419a04d977f5d80e6c55.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '009e68dd75b2d13a5843bf2ec5a2c2ab',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/6c856dee72d9d21b95e4051b93681351.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e1911b5ad3e5a7f26851e7c5c292728b',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/ddc9603a9add0d78f26231f15b107f56.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0bb82b45c37f0f0b36f44a1ca673c2a2',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/c3f6e56b2eec363d0ababbea1a98e78e.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f92f6a40587267931bf930027db9d038',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/34a8a8e877ff8202d88bfe3b12d4ef78.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '80d5e7fd42fa9a470e9d3c2b99452fbf',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/a39990acd69549faa51ab8282bf0d353.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5cc922a7369dadace86832a059e0c1ba',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/8e5426b5fc3304a2f650f94c3beb1597.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '30e5704ef5c0b3fa2893b89797a89307',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/b9c2e143da45bc388e6f65d6414de2c5.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c4e1606b47b4fb6514760d4ae6820e3b',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/5559745f61fda00ca631a90a33d0148f.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '18e8161424390607a57cfc81d8a74ff9',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/258b8de6f1df55f30b88819d1717b600.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c05ceb97f4103715e3b380b45cd3faed',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/da463adbc5c97c81cdfb437e0c3f0862.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f76fbb1640b9a5f2095d1b82b9f9999',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/03f474ce1352c2c104fbc4a2eea12716.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '73c9b534142a3818003b799ca682fd89',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/0176369f806bf4a2a2283a8e598d1996.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82843e43e19b3c6a3d974a96bbe58307',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/7493af545740e10f6b3a7254cf1bba76.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c9ed7fc8c02f373ddda4f678877b30b3',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/f3ae974546ff407299cfa2daeb6349c3.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '00809f201539580ae24a0a01d012d8b8',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/97ebebbc5f0d21674bd69e4f434d914f.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '953092da85e36c88fe6c879dbe31acf9',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/43bc6972488afb61376ed09f77c4ae4b.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3a3b335a4c0e018755d490f716d02bed',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/07a03d785b56ff13c5fb66d5341f7aae.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '35d98844368fa7a37a6be8193c6e11bb',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/0e4d7d943b7f19b8156dd8886b435164.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b3a257399b3fa71697c28b68d5147ccd',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/b10d107d9d503e7e93e0e4e4aaba33ca.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4b8018276a21c421b150527667b5f7f3',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/9fce589b59ce0c3b557ad1d0736ea872.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e04b9a25bcd25aa2379305e56f71e292',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/29f66bd9fe93868900323d4cd993336f.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9473d582908431499a22652f08ed6a4f',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/be2155d0c2bd79fdd31966a14487ddd3.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d7280f0f37bfc4a24dbc5fd03c9e059',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/69a9c4f27a8b2c32b04dd768cb62bb98.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31304f9e976d3a7bf61bd4cf3903bd4c',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/5dc6d14bec1369fd4d5493932553a0b8.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad4a1f44e4aff9751f5b2661d85457a0',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/75fe20ebae44d6d6294c4a1865749522.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7bfbddbafbd99fc83471a49659feef9e',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/af87a32cf2ab523f8d05ae9a59b95f43.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd8f158878e67f8fdf35dccd03d948dbd',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/5b74c86415c385fd7ced9f2b5654ec12.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dfbe26427e2a05f0da9ad1ab4b5d3846',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/fdcb383eb3e71f94e09e15b3b2a26ef1.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a5b53b76c135c32a89534aeccd53255c',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/6d1c17a6cafd294ad03ee0a686d4c8e4.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6347c263cd1a7b641ff62cc31420e906',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/e62b55ada82f8fce363257172eb3f77c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e02b0f145756ebf1798842fae9ccb274',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/3b23618042e69f4a833bf536d6536a7a.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e1d326cf6624a4b9c29bf299c6dde4ff',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/f33e2b8ce8329de1b3b6d2fb6aa6bdca.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '933d7a4026e51721a91c620d6b1f65b5',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/5d21c883a30d97508f199a8895f3b490.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4b3a209d20762a5806cd7f1fb9f6419a',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/b0654e7ec5c5e69e2934ec6d05db7a6e.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cfa9490bdbffc70ff40b09e3a869978d',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/183a8ad83f133f13f6555ec400fd1da8.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e85bcf58fc9c954bd3d2d87c6f6a54b7',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/775d4fc2eaef633c7d2b29d782b0ed9b.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '702027de357c15a198ab20b71f093ba7',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/0fab0f3fa116a4ea692e5d5374128b8e.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '750a6e6615ea9faecc760cd052d2a833',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/fa3fdd2d501400c7ca524bed9be2b959.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4806b6361ff5a9fa6ebad32c08287ca8',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/2ea1f23779122ce30ba3d75c69fbdcc5.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e66d835e90b3f4577115bec3938c92d0',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/0cace0c0bdcbc90c56ab23d7056943be.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '36e6b549d66e576d298d4ab688c40e57',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/f2f41ec610a56f19bbe46cede622d536.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08bb2b5652724c8ff6ce92f4dccb9984',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/a6ca32b4b7aa9dc064b65b95f0cde010.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4b53839f9c07081baa008caf76b7fc65',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/3e53b4cead6e7a81b3ecbbf6b72b52c3.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f18f58b6f20843304149a0bab2019cc',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/e2b79f4d6558e0e3ab166ef52fe5d3fd.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c0b9296fe854e9246cdd600a8ced20b1',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/67e54a5eb8e2ea7f9640a6fb81b3a735.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f3e621c11c57a46bcfbd19256dfb626',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/acc007312e318679a00aa86cdd6a23e5.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f12048d27c8f343744124cc174e01a0b',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/fff4b94687585c754e1883088aa04dd0.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9533e0329472ae869868ea75e5c8fcde',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/ebf2c0fdcfa0948dcebc07b446439e53.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c503044be5af085b9bab911d893af68',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/9dbd8e3fbe6cc805b49516cdff84ad84.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '73f5318e2b0cbba011528a5339c9c7db',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/cc84128eb0016954afd416836131caf5.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a30a4bfb5e11ca7e37edc8c594ab8c97',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/6a8f2e9134193f20fe04ecee0bd82897.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b687f4047e0ed12142ab60447593eed3',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/8d2c48e8e0fe022da80da7cc6642154d.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2fc1058bd8d0315b71f319bc608fa5f5',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/b38686273963fb891a8e16b73d2e234d.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cc9f055d31f5c5ba71328b9731e976b5',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/1aced3bcb9213f6232faa0b7cd67cef3.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '02e550ef7e198f743ed906f88792d947',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/8ea84a2fbc881d077ace1e423ef7a646.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31e69d71eec7bf1fb29883811fa1383b',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/7b5ee43ecce4625d0ac0a373bdaef84c.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4bb2e87c085eef48b18bdfa519a91aac',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/64bd28a36ba7af01990565854efec4e1.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3134343d49391ad717fcb166614ebcd',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/6ad2a355e48696cdd6100350a158cbca.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3b0ab3a7f3cd390b10633a0d7ac78f87',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/fab69c54336192e8a0dde829d1a38c45.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9316c3106fa3da2cc87bcac6ea751311',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/eefe9b8e82c2601f4d54633265314c9e.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd9d7a033f51ec098b6674cf6bfab001f',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/12548168e96f792615ac24b1b8192231.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'feeeb6248a486aa4cd7d418eb9ac6f1f',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/447ccb86e8dca0e0008c09a62f2d3085.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e7c7bc670e0f24a9d8e601aacace0d29',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/4dbd0c5e8a5dc1dc4fa225eac77b5917.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9eede2fbbb233a48aa20e9dfa77db69b',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/20990b371113d1e1c4426f804f88768b.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4fd88562d850ed151a89989f5b75502b',
      'native_key' => 'upload_images',
      'filename' => 'MODX/Revolution/modSystemSetting/a6daaff2834ddedd35a66cd7eecfc182.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7097fe19bf8b3ad138d1da30750f2fcd',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/98ecd89342b48868f6adeb127de4b513.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ec652b3bfdf66e10c09c21bb3ded55c',
      'native_key' => 'upload_media',
      'filename' => 'MODX/Revolution/modSystemSetting/5d1480caf6987eaa1bcf464ed2bce9ab.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd53a392badf03b3fb455c15a4d360ad6',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/d975cfac7510c34eba248bd43cc015d6.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5525b974ade8ae11f913c1fc9ac78693',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/a90ada021e3dc1c072b0c2a2585544a8.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5cb361553ac349653013ac7564f3aafc',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/c8db80e9a49223ab12082ebf2c4377e7.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b6e10e1764477f9db9b4506f3188418e',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/21f628ac2df205118c6bac4b7175c7e6.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2896ce0e6ce1c007c4354655de126cb4',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/be0aeb65c12df54573464033f2dd0bae.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b1adf3b60dfeeffa1fd5211abe20d2ef',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/9c15600e81c6e373033a895c7882f6ce.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '767ac5d7f29d6446761613dfd65862f6',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/522831444567316782585d756c5f2169.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a9f8def90d2f89d499e88e8bd1fbcae8',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/e5f675bfe3bed8d86207b8ccc2c14c47.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b617f5cf14e533a39f94ddc3d1cd47a8',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/01f11b05453be3d1cea0806cb6c57b7e.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd79ffea33c7a378a03a33925f5324c8a',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/7fe836d392b796c941afab537f888e93.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7eee1a53f6803bed46059a46bf869f64',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/5fa80e9f602aa69a22c301b7ff1f8737.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3ef1eea513f93f2355627d536517d3be',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/ee28ecc22c6c7ed095c109872e024c3c.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f8ff8e303ab71118d8cfdf65491cc381',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/faee99329bc6b5459e1b0316c2b95a5a.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f5afb4e44533162cb414951c8f2b77b',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/aa3a7139dfc4fe27db3b4a7b52f15a8c.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '12395205816c147d43ae9fa3673a71b0',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/137f10c5da6d42515dd879959e09b2de.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8ed03b42ec5c0a13a5ed24d2466580d9',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/e966cc98ddaaa3c3abe41aa26855e995.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '457700b8b784fb267072690818c9886e',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/c2136a2f2b513961d0b713abc1476e26.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cdb28584f50a6ee6cdffd30d43345b56',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/7c87f64ba151a08942e5d16edafbf07f.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '13898d5b03be4a5cbfba7ff460608904',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/d65550e648f0888f54a7396775ee8898.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9318a2c3b8f00938d5e5388124bea408',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/e3e5755b9b7b242bd4a661b022d862d0.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bd16c63618dea2d4dfc917324fb49696',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/be5a781c07509ec837ede8c723b25cb5.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4c20cf6e5fe95231739edc7ce64b32c5',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/59d5f3967d0618f9f8cf894193ddeb1c.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd8517a08fabdfd89fb2833ece2a2d27b',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/fe3b994d63d1e3a3ac906f2ca49a727b.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'edcb0a780a7c337a2596a0fc9bae9d00',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/f6956e6c62618c55fb057b6582267c14.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd0a2dc27929172289865ac2f81981308',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/8db20de3d9ba4fae92600c44b9833e21.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e60c10a67954fc55c0d0877d35c44357',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/7bc2b8bbab85dcbe8820f7e736e83bca.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c9c3f20902898acb185b8e9cdec6ae51',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/0949139b941420da5b6ad23fc694d66d.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => 'a0440b15ee10302a82db8b6e0609c78d',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/1854c5f565afc4660c697dfe09982300.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '562b7d6135cb914261ff02a8927584e6',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/921a8b87f5bd4dc650732b494856da6d.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => 'b4459d3008b5de1adc635343a6337048',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/f9fbf9dd1a72d6ea6e8f2b245087124f.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => '4767d3ad93731849d5998ffe14041a9f',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/b487a55304b56e1f02a08b0b70d7aa18.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => 'ed69593b2368421ca6d6580ea5d21770',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/903d1c3d6d6f6c130722e3d191849835.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'a6b273f567661134c281c1fb01ad97cb',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/c29343f839f4b3de49190c660ec630a2.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'd428fbcb134464bf9f7a51546047e07c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/66f49e59db1e82d65313d1af57a865c1.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'ff2721b78d1ab2281a85b829cc4becbb',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/3affb74549ac8dfcf3197f4d29a5e340.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '104ec1ffd2c11c69754d37a7ea58c590',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/4f899ccec2300d43ccd45c5f24a51a87.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '7fd739e002ac2f036c8d8cc19aeab247',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/69d8c1e1dcc33de7e6425b68dfcdbf9c.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'c213e2d3ac4aafd96e0a18800a3e1812',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/f2526f51e2c3dbae0286e789c283357a.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '89b5574bdbb93cf063d987ad0f14b2a9',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/b55bb5b3a89369bc7fe426f10dc9e940.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '3f8dd0fb05ad3c3a21d2044c6404fc23',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/765019d0ed1455544d7e55f31a97339a.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '8b52ac327d8a2d3b75cb69d4dc253aa5',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/f80f07b9e00d99cd4392a09baa6db6d4.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '04f8324ea97fb62b28615c32346f4637',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/3c43cdd6b196d5e3b647443e004ecd00.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '5894d0b9e5fb2d3ea98c89219cd91b26',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/9cee0ce5c95187bc1f31fceb0d815eb6.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '680988ecd6a27ebd1e51828fddf8520f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/3eb9c1b395b741101a5f41e6ec734662.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '408ae8a8558212b63dff05ad08b9ff26',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/2c1a8eace6cb209aae3adf162178b68f.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'b603b0358d1f9d984e62f042f6bccb59',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/e0ca87b5293bb948595070ee27d76de8.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'd044e20d7d653b559e62d23600801727',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/21209cabc1d3196a65d4f4f58a4b3992.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '042ac3d2e411f89de5b7b7be582c19e6',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/764e1db7b6a7121070c0217f86dc59cd.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'c3630d1b2f0b66e52c2319a504d262cd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/38b0dc9b74473b668439539460ac35f0.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '165ce4b9bec38520808182ed75b56f71',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/2a588bcf57f8ed3970808c6c45462136.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'f03a1d68507a83ae0560d7128a8e99c3',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/ad59d808d936a4058df8e196c2f40d98.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '66fe71cf8ca71ddc287ab1532cdac718',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/9de1f2efd8138c30eb02bf36c9d665fa.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '6b84ec5e1fb3edaedb57d118f10fa878',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/8786f9e3d4dbdca1d16b1ee93f71318e.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '449c5abcbc65e9df72e730f9585c7f64',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/742fbcbd0d39d6f97430dc536c7024e9.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '2ef4f0e7125b9c5680709154730b12a5',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/3ff77503f7910e2fce378ccd9c3fa52e.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '8d633f6c10f6113e025154e942f4e871',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/91c3ed904fdb0a075cc7213165061515.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '77aadb6cd60a49f3745975ed614c20b0',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/845417838b9b1413e76c01acdf7a9702.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '42c3a30f2e9cf371c27f2fb732015132',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/9bdc801e2575dc1def31d93f9b2c5aa3.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '6db86cabf462110f7859902c57a79a64',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/18b4e406265138c9a6fe190e3b745240.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '6174b896c2dbfc25eef8ec79fd99bb78',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/c4e0efa4a13404ad5c8bacd7ea8f1595.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '198f3b498f684b8e384c1d0ca7f9324c',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/6d263573557a3009dd1f3c52a83e6a3b.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'e4c90dba9fcb474d0762bd92d644f5b1',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/5558ac9f3cb9bdc4765a0df63857c78f.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '377553149ae5afaf3016e6d3400f7399',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/3c9fa1a313f929d89e7903f1ebf04af6.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '91b6cd293cc9cedb374c648a8b3d96eb',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/edb9e1bebe043512bc4a8228a6223b7f.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c4f96ac4f20ad49bf18b02600ac2f3ff',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/e5cca47b4f407b19465974ccd806b3f6.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '304ab497a3dfb23aa81772dd71a67ea7',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/5c7bf59dc9cd0ca08bcc48201ea457d5.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '436457695f36a2af4ff3d502353190ca',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/b5915e231a94883995055a69efaed731.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '8081c185a40d160067a674d5ca8fae1d',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/a64bd848d4404c026280d8b44c3d81cf.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '4cc10efb6fd843b40a600b80c039abdd',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/1f3fbc47c0a5fdedd1e78685da931bc2.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '5bf1dbdbdb3ae5fd70922900077d9494',
      'native_key' => '5bf1dbdbdb3ae5fd70922900077d9494',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/5c10a04ac686cfb033205aa364728408.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'da57e6e39306d60124f641fec7db004b',
      'native_key' => 'da57e6e39306d60124f641fec7db004b',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/cfaedd759d736f08a45ab5baf6da9841.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '641d6c6d5ef088b5f1918ce3188d2e83',
      'native_key' => '641d6c6d5ef088b5f1918ce3188d2e83',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/a79d9e5b3d56083930110680ce139b8b.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'c20d5ab67a2f2728fcc575ea98304de7',
      'native_key' => 'c20d5ab67a2f2728fcc575ea98304de7',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/ee5bc7617a1d674652828e43a932b8a5.vehicle',
    ),
  ),
);